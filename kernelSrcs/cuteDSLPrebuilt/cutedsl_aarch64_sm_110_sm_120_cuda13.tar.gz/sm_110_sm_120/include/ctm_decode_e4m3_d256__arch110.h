
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} ctm_decode_e4m3_d256__arch110_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_ctm_decode_e4m3_d256__arch110_cuda_init(void **);
void _mlir_ctm_decode_e4m3_d256__arch110_cuda_load_to_device(void **);
static inline void ctm_decode_e4m3_d256__arch110_Kernel_Module_Load(ctm_decode_e4m3_d256__arch110_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_ctm_decode_e4m3_d256__arch110_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_ctm_decode_e4m3_d256__arch110_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void ctm_decode_e4m3_d256__arch110_Kernel_Module_Unload(ctm_decode_e4m3_d256__arch110_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
#endif
void _mlir_ctm_decode_e4m3_d256__arch110__mlir_ciface_cutlass_launch_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_____________CUstream0x0_Ptrgmem_(void **args, int32_t num_args);

static inline int32_t cute_dsl_ctm_decode_e4m3_d256__arch110_wrapper(ctm_decode_e4m3_d256__arch110_Kernel_Module_t *module, void *pQ, void *pKV, void *pPT, void *pSL, void *pSNK, void *pO, void *pWS, void *pWH, void *pSEM, int32_t B, int32_t HKV, int32_t NP2, int32_t MAXP, int32_t gqa, int32_t splits, int32_t csplit, int32_t window, int32_t has_sink, int32_t hk_shift, float qk_scale, float v_scale, cudaStream_t stream, void *pSKT, int32_t skt_len) {
    int32_t ret = 0;
    void *args[25] = {
        &pQ, &pKV, &pPT, &pSL, &pSNK, &pO, &pWS, &pWH, &pSEM, &B, &HKV, &NP2, &MAXP, &gqa, &splits, &csplit, &window, &has_sink, &hk_shift, &qk_scale, &v_scale, &stream, &pSKT, &skt_len,
        &ret
    };
    _mlir_ctm_decode_e4m3_d256__arch110__mlir_ciface_cutlass_launch_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_____________CUstream0x0_Ptrgmem_(args, 25);
    return ret;
}
