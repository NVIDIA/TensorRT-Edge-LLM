
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} w2a16_moe_prefill_m64__arch120_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_w2a16_moe_prefill_m64__arch120_cuda_init(void **);
void _mlir_w2a16_moe_prefill_m64__arch120_cuda_load_to_device(void **);
static inline void w2a16_moe_prefill_m64__arch120_Kernel_Module_Load(w2a16_moe_prefill_m64__arch120_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_w2a16_moe_prefill_m64__arch120_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_w2a16_moe_prefill_m64__arch120_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void w2a16_moe_prefill_m64__arch120_Kernel_Module_Unload(w2a16_moe_prefill_m64__arch120_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
#endif
void _mlir_w2a16_moe_prefill_m64__arch120__mlir_ciface_cutlass___call_____main__MoeLaunch_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgme(void **args, int32_t num_args);

static inline int32_t cute_dsl_w2a16_moe_prefill_m64__arch120_wrapper(w2a16_moe_prefill_m64__arch120_Kernel_Module_t *module, void *x, void *w1, void *w2, void *s1, void *s2, void *unit, void *lut, void *routes, void *experts, void *route_count, void *route_weights, void *activated, void *slots, void *output, void *scratch1, void *scratch2, void *locks, int32_t m, int32_t e, int32_t intermediate_size, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[22] = {
        &x, &w1, &w2, &s1, &s2, &unit, &lut, &routes, &experts, &route_count, &route_weights, &activated, &slots, &output, &scratch1, &scratch2, &locks, &m, &e, &intermediate_size, &stream,
        &ret
    };
    _mlir_w2a16_moe_prefill_m64__arch120__mlir_ciface_cutlass___call_____main__MoeLaunch_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgme(args, 22);
    return ret;
}
