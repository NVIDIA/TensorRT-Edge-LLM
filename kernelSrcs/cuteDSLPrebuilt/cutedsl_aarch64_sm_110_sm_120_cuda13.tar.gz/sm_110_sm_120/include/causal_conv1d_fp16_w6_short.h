
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} causal_conv1d_fp16_w6_short_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_causal_conv1d_fp16_w6_short_cuda_init(void **);
void _mlir_causal_conv1d_fp16_w6_short_cuda_load_to_device(void **);
static inline void causal_conv1d_fp16_w6_short_Kernel_Module_Load(causal_conv1d_fp16_w6_short_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_causal_conv1d_fp16_w6_short_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_causal_conv1d_fp16_w6_short_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void causal_conv1d_fp16_w6_short_Kernel_Module_Unload(causal_conv1d_fp16_w6_short_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} causal_conv1d_fp16_w6_short_Tensor_x_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} causal_conv1d_fp16_w6_short_Tensor_cu_seqlens_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} causal_conv1d_fp16_w6_short_Tensor_state_indices_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} causal_conv1d_fp16_w6_short_Tensor_has_initial_state_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} causal_conv1d_fp16_w6_short_Tensor_weight_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} causal_conv1d_fp16_w6_short_Tensor_bias_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} causal_conv1d_fp16_w6_short_Tensor_conv_states_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} causal_conv1d_fp16_w6_short_Tensor_out_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_causal_conv1d_fp16_w6_short__mlir_ciface_cutlass___call_____main__PackedCausalConv1d_object_at__FakeTensorFloat16div11_FakeTensorInt32div11_FakeTensorInt32div11_FakeTensorInt32div11_FakeTensorFloat16div11_FakeTensorFloat1(void **args, int32_t num_args);

static inline int32_t cute_dsl_causal_conv1d_fp16_w6_short_wrapper(causal_conv1d_fp16_w6_short_Kernel_Module_t *module, causal_conv1d_fp16_w6_short_Tensor_x_t *x, causal_conv1d_fp16_w6_short_Tensor_cu_seqlens_t *cu_seqlens, causal_conv1d_fp16_w6_short_Tensor_state_indices_t *state_indices, causal_conv1d_fp16_w6_short_Tensor_has_initial_state_t *has_initial_state, causal_conv1d_fp16_w6_short_Tensor_weight_t *weight, causal_conv1d_fp16_w6_short_Tensor_bias_t *bias, causal_conv1d_fp16_w6_short_Tensor_conv_states_t *conv_states, causal_conv1d_fp16_w6_short_Tensor_out_t *out, int32_t total_tokens, int32_t num_sequences, int32_t dim, int32_t num_slots, int32_t pad_slot_id, int32_t has_bias, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[16] = {
        x, cu_seqlens, state_indices, has_initial_state, weight, bias, conv_states, out, &total_tokens, &num_sequences, &dim, &num_slots, &pad_slot_id, &has_bias, &stream,
        &ret
    };
    _mlir_causal_conv1d_fp16_w6_short__mlir_ciface_cutlass___call_____main__PackedCausalConv1d_object_at__FakeTensorFloat16div11_FakeTensorInt32div11_FakeTensorInt32div11_FakeTensorInt32div11_FakeTensorFloat16div11_FakeTensorFloat1(args, 16);
    return ret;
}
