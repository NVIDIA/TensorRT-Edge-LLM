
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} fmha_v2_vit_d96__arch110_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_fmha_v2_vit_d96__arch110_cuda_init(void **);
void _mlir_fmha_v2_vit_d96__arch110_cuda_load_to_device(void **);
static inline void fmha_v2_vit_d96__arch110_Kernel_Module_Load(fmha_v2_vit_d96__arch110_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_fmha_v2_vit_d96__arch110_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_fmha_v2_vit_d96__arch110_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void fmha_v2_vit_d96__arch110_Kernel_Module_Unload(fmha_v2_vit_d96__arch110_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} fmha_v2_vit_d96__arch110_Tensor_q_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} fmha_v2_vit_d96__arch110_Tensor_k_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} fmha_v2_vit_d96__arch110_Tensor_v_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} fmha_v2_vit_d96__arch110_Tensor_o_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} fmha_v2_vit_d96__arch110_Tensor_cu_seqlens_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_fmha_v2_vit_d96__arch110__mlir_ciface_cutlass___call_vit_____main__FMHAV2Ampere_object_at__FakeTensorFloat16div1div196i64div96961_FakeTensorFloat16div1div196i64div96961_FakeTensorFloat16div1div196i64div96961_FakeTensor(void **args, int32_t num_args);

static inline int32_t cute_dsl_fmha_v2_vit_d96__arch110_wrapper(fmha_v2_vit_d96__arch110_Kernel_Module_t *module, fmha_v2_vit_d96__arch110_Tensor_q_tensor_t *q_tensor, fmha_v2_vit_d96__arch110_Tensor_k_tensor_t *k_tensor, fmha_v2_vit_d96__arch110_Tensor_v_tensor_t *v_tensor, fmha_v2_vit_d96__arch110_Tensor_o_tensor_t *o_tensor, fmha_v2_vit_d96__arch110_Tensor_cu_seqlens_t *cu_seqlens, int32_t max_seqlen, float scale_softmax_log2, float scale_softmax, float scale_output, int32_t sm_count, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[12] = {
        q_tensor, k_tensor, v_tensor, o_tensor, cu_seqlens, &max_seqlen, &scale_softmax_log2, &scale_softmax, &scale_output, &sm_count, &stream,
        &ret
    };
    _mlir_fmha_v2_vit_d96__arch110__mlir_ciface_cutlass___call_vit_____main__FMHAV2Ampere_object_at__FakeTensorFloat16div1div196i64div96961_FakeTensorFloat16div1div196i64div96961_FakeTensorFloat16div1div196i64div96961_FakeTensor(args, 12);
    return ret;
}
