
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} lora_blackwell_metadata_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_lora_blackwell_metadata_cuda_init(void **);
void _mlir_lora_blackwell_metadata_cuda_load_to_device(void **);
static inline void lora_blackwell_metadata_Kernel_Module_Load(lora_blackwell_metadata_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_lora_blackwell_metadata_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_lora_blackwell_metadata_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void lora_blackwell_metadata_Kernel_Module_Unload(lora_blackwell_metadata_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
#endif
void _mlir_lora_blackwell_metadata__mlir_ciface_cutlass_wrapper___main__MetadataExportWrapper_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_________CUs(void **args, int32_t num_args);

static inline int32_t cute_dsl_lora_blackwell_metadata_wrapper(lora_blackwell_metadata_Kernel_Module_t *module, void *input_ptr, void *lora_a_ptr, void *lora_b_ptr, void *workspace_ptr, void *output_ptr, void *segment_offsets_ptr, void *segment_adapter_ids_ptr, void *adapter_ranks_ptr, void *adapter_scales_ptr, void *problem_shapes_ptr, void *strides_ptr, void *addresses_ptr, void *logical_k_sizes_ptr, void *group_scales_ptr, int32_t total_rows, int32_t input_size, int32_t output_size, int32_t max_rank, int32_t num_segments, int32_t num_adapters, int32_t second_stage, int32_t work_items, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[24] = {
        &input_ptr, &lora_a_ptr, &lora_b_ptr, &workspace_ptr, &output_ptr, &segment_offsets_ptr, &segment_adapter_ids_ptr, &adapter_ranks_ptr, &adapter_scales_ptr, &problem_shapes_ptr, &strides_ptr, &addresses_ptr, &logical_k_sizes_ptr, &group_scales_ptr, &total_rows, &input_size, &output_size, &max_rank, &num_segments, &num_adapters, &second_stage, &work_items, &stream,
        &ret
    };
    _mlir_lora_blackwell_metadata__mlir_ciface_cutlass_wrapper___main__MetadataExportWrapper_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_________CUs(args, 24);
    return ret;
}
