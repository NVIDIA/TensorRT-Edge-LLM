
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} fmha_d256_packed_paged_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_fmha_d256_packed_paged_cuda_init(void **);
void _mlir_fmha_d256_packed_paged_cuda_load_to_device(void **);
static inline void fmha_d256_packed_paged_Kernel_Module_Load(fmha_d256_packed_paged_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_fmha_d256_packed_paged_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_fmha_d256_packed_paged_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void fmha_d256_packed_paged_Kernel_Module_Unload(fmha_d256_packed_paged_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} fmha_d256_packed_paged_Tensor_q_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} fmha_d256_packed_paged_Tensor_kv_cache_pool_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} fmha_d256_packed_paged_Tensor_kv_cache_page_list_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} fmha_d256_packed_paged_Tensor_o_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} fmha_d256_packed_paged_Tensor_cum_seqlen_k_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} fmha_d256_packed_paged_Tensor_cum_seqlen_q_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_fmha_d256_packed_paged__mlir_ciface_cutlass___call_paged_ragged_____main__BlackwellFusedMultiHeadAttentionForwardHeadDimPerCta256_object_at__FakeTensorFloat16div1div1div1i64div1i64div11_FakeTensorFloat16div1div1div1d(void **args, int32_t num_args);

static inline int32_t cute_dsl_fmha_d256_packed_paged_wrapper(fmha_d256_packed_paged_Kernel_Module_t *module, fmha_d256_packed_paged_Tensor_q_tensor_t *q_tensor, fmha_d256_packed_paged_Tensor_kv_cache_pool_t *kv_cache_pool, fmha_d256_packed_paged_Tensor_kv_cache_page_list_t *kv_cache_page_list, fmha_d256_packed_paged_Tensor_o_tensor_t *o_tensor, fmha_d256_packed_paged_Tensor_cum_seqlen_k_t *cum_seqlen_k, int32_t window_size_left, float attention_scale, float scale_q, float scale_k, float scale_v, float inv_scale_o, int32_t sm_count, cudaStream_t stream, fmha_d256_packed_paged_Tensor_cum_seqlen_q_t *cum_seqlen_q, int32_t max_seqlen_q) {
    int32_t ret = 0;
    void *args[16] = {
        q_tensor, kv_cache_pool, kv_cache_page_list, o_tensor, cum_seqlen_k, &window_size_left, &attention_scale, &scale_q, &scale_k, &scale_v, &inv_scale_o, &sm_count, &stream, cum_seqlen_q, &max_seqlen_q,
        &ret
    };
    _mlir_fmha_d256_packed_paged__mlir_ciface_cutlass___call_paged_ragged_____main__BlackwellFusedMultiHeadAttentionForwardHeadDimPerCta256_object_at__FakeTensorFloat16div1div1div1i64div1i64div11_FakeTensorFloat16div1div1div1d(args, 16);
    return ret;
}
