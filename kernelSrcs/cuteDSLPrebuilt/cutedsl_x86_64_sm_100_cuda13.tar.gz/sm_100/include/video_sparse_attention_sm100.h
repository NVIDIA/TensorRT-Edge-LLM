
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} video_sparse_attention_sm100_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_video_sparse_attention_sm100_cuda_init(void **);
void _mlir_video_sparse_attention_sm100_cuda_load_to_device(void **);
static inline void video_sparse_attention_sm100_Kernel_Module_Load(video_sparse_attention_sm100_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_video_sparse_attention_sm100_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_video_sparse_attention_sm100_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void video_sparse_attention_sm100_Kernel_Module_Unload(video_sparse_attention_sm100_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
    int64_t dynamic_strides[1];
} video_sparse_attention_sm100_Tensor_q_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
    int64_t dynamic_strides[1];
} video_sparse_attention_sm100_Tensor_k_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
    int64_t dynamic_strides[1];
} video_sparse_attention_sm100_Tensor_v_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
    int64_t dynamic_strides[1];
} video_sparse_attention_sm100_Tensor_output_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
    int64_t dynamic_strides[1];
} video_sparse_attention_sm100_Tensor_kc_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
    int64_t dynamic_strides[1];
} video_sparse_attention_sm100_Tensor_vc_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
    int64_t dynamic_strides[1];
} video_sparse_attention_sm100_Tensor_threshold_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_video_sparse_attention_sm100__mlir_ciface_cutlass_dynamic_sparse_attention_sm100_FakeTensorBFloat16_1_div1_56_128_i64_div7168_7168_128_1_FakeTensorBFloat16_1_div1_56_128_i64_div7168_7168_128_1_FakeTensorBFloat16_1_div1_56_(void **args, int32_t num_args);

static inline int32_t cute_dsl_video_sparse_attention_sm100_wrapper(video_sparse_attention_sm100_Kernel_Module_t *module, video_sparse_attention_sm100_Tensor_q_t *q, video_sparse_attention_sm100_Tensor_k_t *k, video_sparse_attention_sm100_Tensor_v_t *v, video_sparse_attention_sm100_Tensor_output_t *output, video_sparse_attention_sm100_Tensor_kc_t *kc, video_sparse_attention_sm100_Tensor_vc_t *vc, video_sparse_attention_sm100_Tensor_threshold_t *threshold, int32_t conditioning_tokens, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[10] = {
        q, k, v, output, kc, vc, threshold, &conditioning_tokens, &stream,
        &ret
    };
    _mlir_video_sparse_attention_sm100__mlir_ciface_cutlass_dynamic_sparse_attention_sm100_FakeTensorBFloat16_1_div1_56_128_i64_div7168_7168_128_1_FakeTensorBFloat16_1_div1_56_128_i64_div7168_7168_128_1_FakeTensorBFloat16_1_div1_56_(args, 10);
    return ret;
}
