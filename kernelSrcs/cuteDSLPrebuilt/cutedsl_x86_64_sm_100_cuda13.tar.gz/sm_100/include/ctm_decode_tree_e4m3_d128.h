
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} ctm_decode_tree_e4m3_d128_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_ctm_decode_tree_e4m3_d128_cuda_init(void **);
void _mlir_ctm_decode_tree_e4m3_d128_cuda_load_to_device(void **);
static inline void ctm_decode_tree_e4m3_d128_Kernel_Module_Load(ctm_decode_tree_e4m3_d128_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_ctm_decode_tree_e4m3_d128_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_ctm_decode_tree_e4m3_d128_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void ctm_decode_tree_e4m3_d128_Kernel_Module_Unload(ctm_decode_tree_e4m3_d128_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
#endif
void _mlir_ctm_decode_tree_e4m3_d128__mlir_ciface_cutlass_launch_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem___________________CUstream0x0(void **args, int32_t num_args);

static inline int32_t cute_dsl_ctm_decode_tree_e4m3_d128_wrapper(ctm_decode_tree_e4m3_d128_Kernel_Module_t *module, void *pQ, void *pKV, void *pPT, void *pSL, void *pSNK, void *pO, void *pWS, void *pWH, void *pSEM, void *pTM, int32_t B, int32_t HKV, int32_t NP2, int32_t MAXP, int32_t gqa, int32_t splits, int32_t W, int32_t CQ, int32_t SNK, int32_t S, int32_t MW, int32_t RB, int32_t DSH, int32_t RBM, int32_t GQM, int32_t SPLM, float qk_scale, float v_scale, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[30] = {
        &pQ, &pKV, &pPT, &pSL, &pSNK, &pO, &pWS, &pWH, &pSEM, &pTM, &B, &HKV, &NP2, &MAXP, &gqa, &splits, &W, &CQ, &SNK, &S, &MW, &RB, &DSH, &RBM, &GQM, &SPLM, &qk_scale, &v_scale, &stream,
        &ret
    };
    _mlir_ctm_decode_tree_e4m3_d128__mlir_ciface_cutlass_launch_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem___________________CUstream0x0(args, 30);
    return ret;
}
