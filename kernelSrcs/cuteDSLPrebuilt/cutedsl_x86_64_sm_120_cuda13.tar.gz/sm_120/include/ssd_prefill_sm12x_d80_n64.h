
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} ssd_prefill_sm12x_d80_n64_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_ssd_prefill_sm12x_d80_n64_cuda_init(void **);
void _mlir_ssd_prefill_sm12x_d80_n64_cuda_load_to_device(void **);
static inline void ssd_prefill_sm12x_d80_n64_Kernel_Module_Load(ssd_prefill_sm12x_d80_n64_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_ssd_prefill_sm12x_d80_n64_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_ssd_prefill_sm12x_d80_n64_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void ssd_prefill_sm12x_d80_n64_Kernel_Module_Unload(ssd_prefill_sm12x_d80_n64_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} ssd_prefill_sm12x_d80_n64_Tensor_x_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} ssd_prefill_sm12x_d80_n64_Tensor_dt_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} ssd_prefill_sm12x_d80_n64_Tensor_a_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} ssd_prefill_sm12x_d80_n64_Tensor_b_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} ssd_prefill_sm12x_d80_n64_Tensor_c_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} ssd_prefill_sm12x_d80_n64_Tensor_d_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} ssd_prefill_sm12x_d80_n64_Tensor_dt_bias_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} ssd_prefill_sm12x_d80_n64_Tensor_cu_seqlens_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} ssd_prefill_sm12x_d80_n64_Tensor_state_indices_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} ssd_prefill_sm12x_d80_n64_Tensor_state_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} ssd_prefill_sm12x_d80_n64_Tensor_output_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} ssd_prefill_sm12x_d80_n64_Tensor_dt_processed_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} ssd_prefill_sm12x_d80_n64_Tensor_prefix_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_ssd_prefill_sm12x_d80_n64__mlir_ciface_cutlass___call_____main__PackedSSD_object_at__FakeTensorFloat16div1div1div80i64div80i64div801_FakeTensorFloat16div1div1i64div11_FakeTensorFloat32div11_FakeTensorFloat16div1div1div6(void **args, int32_t num_args);

static inline int32_t cute_dsl_ssd_prefill_sm12x_d80_n64_wrapper(ssd_prefill_sm12x_d80_n64_Kernel_Module_t *module, ssd_prefill_sm12x_d80_n64_Tensor_x_t *x, ssd_prefill_sm12x_d80_n64_Tensor_dt_t *dt, ssd_prefill_sm12x_d80_n64_Tensor_a_t *a, ssd_prefill_sm12x_d80_n64_Tensor_b_t *b, ssd_prefill_sm12x_d80_n64_Tensor_c_t *c, ssd_prefill_sm12x_d80_n64_Tensor_d_t *d, ssd_prefill_sm12x_d80_n64_Tensor_dt_bias_t *dt_bias, ssd_prefill_sm12x_d80_n64_Tensor_cu_seqlens_t *cu_seqlens, ssd_prefill_sm12x_d80_n64_Tensor_state_indices_t *state_indices, ssd_prefill_sm12x_d80_n64_Tensor_state_t *state, ssd_prefill_sm12x_d80_n64_Tensor_output_t *output, ssd_prefill_sm12x_d80_n64_Tensor_dt_processed_t *dt_processed, ssd_prefill_sm12x_d80_n64_Tensor_prefix_t *prefix, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[15] = {
        x, dt, a, b, c, d, dt_bias, cu_seqlens, state_indices, state, output, dt_processed, prefix, &stream,
        &ret
    };
    _mlir_ssd_prefill_sm12x_d80_n64__mlir_ciface_cutlass___call_____main__PackedSSD_object_at__FakeTensorFloat16div1div1div80i64div80i64div801_FakeTensorFloat16div1div1i64div11_FakeTensorFloat32div11_FakeTensorFloat16div1div1div6(args, 15);
    return ret;
}

#ifdef __cplusplus
static constexpr int32_t ssd_prefill_sm12x_d80_n64_kSCAN_GROUP_SIZE = 512;
#endif
